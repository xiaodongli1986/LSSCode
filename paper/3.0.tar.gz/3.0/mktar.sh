ver=3.0
rm -rf $ver
mkdir -p $ver
cp apjfonts.sty $ver
cp mktar.sh $ver
cp aastex62.cls $ver
#cp aastex61.cls $ver
cp mcf_v$ver.tex $ver
cp *.eps $ver
cp cites.bib $ver
#cp apjfonts.sty $ver
#rm $ver/Draft*.pdf
tar -cvf $ver.tar.gz $ver

